# pylint: disable=wildcard-import,unused-import,unused-wildcard-import,no-name-in-module
from pymupdf import *
from pymupdf import _as_fz_document
from pymupdf import _as_fz_page
from pymupdf import _as_pdf_document
from pymupdf import _as_pdf_page
from pymupdf import _log_items
from pymupdf import _log_items_active
from pymupdf import _log_items_clear
from pymupdf import __version__
from pymupdf import __doc__
from pymupdf import _globals
from pymupdf import _g_out_message

message_warning('The `fitz` API is deprecated and will be removed in future. Use `import pymupdf` instead.')
